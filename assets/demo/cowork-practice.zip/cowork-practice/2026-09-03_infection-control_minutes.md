# Infection Control Committee — minutes (SYNTHETIC, for training only)
Date: 3 September 2026. Chair: Infection control lead.

## Decisions
1. Hand-hygiene audits move from monthly to every two weeks on all inpatient floors. Owner: Infection control nurse. Due: 1 October 2026.
2. New signage at ward entrances for contact precautions. Owner: Facilities. Due: 15 October 2026.
3. Central-line bundle checklist to be added to the nursing handover form. Owner: Nursing education. Due: 31 October 2026.

## Discussion
Compliance dipped in August (see quality-counts.csv). Members agreed the dip followed the summer staff rotation.
