# Pharmacy & Therapeutics Committee — minutes (SYNTHETIC, for training only)
Date: 10 September 2026. Chair: Head of pharmacy.

## Decisions
1. Antiemetic order set to be reviewed against the current institutional guideline. Owner: Clinical pharmacist, oncology. Due: 30 October 2026.
2. Monthly report of high-alert medication near-misses to the quality office. Owner: Medication safety officer. Due: first report 5 October 2026.
3. Formulary request for a new oral antifungal deferred to the next meeting pending cost data. Owner: Pharmacy procurement. Due: 8 October 2026.
