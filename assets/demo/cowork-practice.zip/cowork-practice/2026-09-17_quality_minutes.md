# Quality & Patient Safety Committee — minutes (SYNTHETIC, for training only)
Date: 17 September 2026. Chair: Director of quality.

## Decisions
1. Department heads to present one quality indicator each at the November meeting. Owner: Each department head. Due: 12 November 2026.
2. Falls-prevention huddle piloted on two inpatient floors for six weeks. Owner: Nursing managers. Due: start 1 October 2026.
3. Quality dashboard training for unit managers. Owner: AI & Data Intelligence office. Due: 20 October 2026.
