Practice folder for the KHCC Claude Cowork tutorial.
Every file here is synthetic. No patient, staff member, or real meeting is described.
